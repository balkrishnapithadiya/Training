package Model;
import java.util.*;
import Bean.vehicleBean;
import java.sql.*;
public class vehicleModel {
	dbConnection dc = new dbConnection();
    Connection con=dc.getConnection();
    private static final String insert_vehicle = "insert into vehicle (type, photo, color, reg_num, user_id) values (?, ?, ?, ?, ?)";
    private static final String select = "select * from vehicle";
    private static final String delete = "delete from vehicle where id=?";
    private static final String update = "update vehicle set type=?, photo=?, color=?, reg_num=? where id=?";
    private static final String vupdate = "update vehicle set type=?, photo=?, color=?, reg_num=? where reg_num=?";
    private static final String select_my_vehicle = "select * from vehicle where reg_num=? and user_id=?";
    private static final String selectuid = "select * from vehicle where user_id=?";
    private static final String select_vehicle = "select * from vehicle where id=?";
    private static final String selectv = "select * from vehicle where reg_num=?";
    
    public void insert(vehicleBean h) throws SQLException {
        try {
        	PreparedStatement preparedStatement = con.prepareStatement(insert_vehicle);
            preparedStatement.setString(1, h.getType());
            preparedStatement.setString(2, h.getPhoto());
            preparedStatement.setString(3, h.getColor());
            preparedStatement.setString(4, h.getReg_num());
            preparedStatement.setInt(5, h.getUid());
            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
        	printSQLException(e);
        	con.close();
        }
    }
    
    public List < vehicleBean > selectAll() throws SQLException {
    	
        List < vehicleBean > vl = new ArrayList < > ();
        try {
	        PreparedStatement preparedStatement = con.prepareStatement(select);
            ResultSet rs = preparedStatement.executeQuery();

            while (rs.next()) {
            	int id = rs.getInt("id");
                String type = rs.getString("type");
                String photo = rs.getString("photo");
                String reg_num = rs.getString("reg_num");
                String color = rs.getString("color");
                vl.add(new vehicleBean(id, type, reg_num, color, photo));
            }
	        } catch (SQLException e) {
	            printSQLException(e);
	            con.close();
	        }
        return vl;
    }
    
    public boolean delete(int id) throws SQLException {
        boolean rowDeleted = false;
        try { 
        	PreparedStatement statement = con.prepareStatement(delete);
            statement.setInt(1, id);
            System.out.println(statement);
            rowDeleted = statement.executeUpdate() > 0;
        }
        catch (SQLException e) {
            printSQLException(e);
            con.close();
        }
        return rowDeleted;
    }
    
    public boolean update(vehicleBean h) throws SQLException {
        boolean rowUpdated = false;
        try{
        	PreparedStatement statement = con.prepareStatement(update);
            statement.setString(1, h.getType());
            statement.setString(2, h.getPhoto());
            statement.setString(3, h.getColor());
            statement.setString(4, h.getReg_num());
            statement.setInt(5, h.getId());
            System.out.println(statement);
            rowUpdated = statement.executeUpdate() > 0;
        }
        catch (SQLException e) {
            printSQLException(e);
            con.close();
        }
        return rowUpdated;
    }
    
    public boolean vupdate(vehicleBean h) throws SQLException {
        boolean rowUpdated = false;
        try{
        	PreparedStatement statement = con.prepareStatement(vupdate);
            statement.setString(1, h.getType());
            statement.setString(2, h.getPhoto());
            statement.setString(3, h.getColor());
            statement.setString(4, h.getReg_num());
            statement.setString(5, h.getReg_num());
            System.out.println(statement);
            rowUpdated = statement.executeUpdate() > 0;
        }
        catch (SQLException e) {
            printSQLException(e);
            con.close();
        }
        return rowUpdated;
    }
    
	public List < vehicleBean > selectMyVehicle(String reg_num, int id) throws SQLException {
	    	
	        List < vehicleBean > v = new ArrayList < > ();
	        try {
		        PreparedStatement preparedStatement = con.prepareStatement(select_my_vehicle);
		        preparedStatement.setString(1, reg_num);
		        preparedStatement.setInt(2, id);
		        System.out.println(preparedStatement);
	            ResultSet rs = preparedStatement.executeQuery();
	            while (rs.next()) {
	                String type = rs.getString("type");
	                String color = rs.getString("color");
	                String photo = rs.getString("photo");
	                String reg = rs.getString("reg_num");
	                v.add(new vehicleBean(type, reg, photo, color));
	            }
		        } catch (SQLException e) {
		            printSQLException(e);
		            con.close();
		        }
	        return v;
	    }
	
	public List < vehicleBean > selectMyVehicle(int uid) throws SQLException {
    	
        List < vehicleBean > vn = new ArrayList < > ();
        try {
	        PreparedStatement preparedStatement = con.prepareStatement(selectuid);
	        preparedStatement.setInt(1, uid);
	        System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
            	int id = rs.getInt("id");
                String type = rs.getString("type");
                String color = rs.getString("color");
                String photo = rs.getString("photo");
                String reg = rs.getString("reg_num");
                vn.add(new vehicleBean(id, type, reg, color, photo));
            }
	        } catch (SQLException e) {
	            printSQLException(e);
	            con.close();
	        }
        return vn;
    }
	
	public vehicleBean select(int id) {
		vehicleBean h = null;
		try {
            PreparedStatement preparedStatement = con.prepareStatement(select_vehicle);
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                String type = rs.getString("type");
                String photo = rs.getString("photo");
                String color = rs.getString("color");
                String reg_num = rs.getString("reg_num");
                h = new vehicleBean(id, type, reg_num, color, photo);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return h;
    }
	
	public vehicleBean select(String reg_num) {
		vehicleBean h = null;
		try {
            PreparedStatement preparedStatement = con.prepareStatement(selectv);
            preparedStatement.setString(1, reg_num);
            System.out.println(preparedStatement);
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
            	int id = rs.getInt("id");
                String type = rs.getString("type");
                String photo = rs.getString("photo");
                String color = rs.getString("color");
                h = new vehicleBean(id, type, reg_num, color, photo);
            }
        } catch (SQLException e) {
            printSQLException(e);
        }
        return h;
    }
    
    private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
