package Model;
import Bean.loginBean;
import java.sql.*;
public class loginModel {
	public boolean validate(loginBean loginBean) throws ClassNotFoundException, SQLException {

        String e = loginBean.getEmail();
        String p = loginBean.getPassword();
        boolean status = false;
        dbConnection dc = new dbConnection();
        Connection con=dc.getConnection();
        try{
	        PreparedStatement ps = con.prepareStatement("select * from user where email=? and pass=?");
	        ps.setString(1, e);
	        ps.setString(2, p);
	        ResultSet rs = ps.executeQuery();
	        status = rs.next();
	        } catch (SQLException se) {
            System.out.println(se);
            con.close();
        }
        return status;
    }
}
