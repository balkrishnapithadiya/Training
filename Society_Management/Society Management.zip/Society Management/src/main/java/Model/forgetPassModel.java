package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class forgetPassModel {
	public boolean forget(String email) throws SQLException
	{
		boolean status = false;
        dbConnection dc = new dbConnection();
        Connection con=dc.getConnection();
		try{
	        PreparedStatement ps = con.prepareStatement("select * from user where email=?");
	        ps.setString(1, email);
	        ResultSet rs = ps.executeQuery();
	        status = rs.next();
	        } catch (SQLException se) {
            System.out.println(se);
            con.close();
        }
		return status;
	}
}
