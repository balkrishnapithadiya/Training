package Model;
import java.sql.*;
public class dbConnection {
	public Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_society","root","");
        } catch (SQLException | ClassNotFoundException e) {
        	e.printStackTrace();
        }
        return connection;
    }
}
