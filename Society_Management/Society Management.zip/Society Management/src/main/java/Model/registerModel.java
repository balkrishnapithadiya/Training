package Model;
import Bean.registerBean;
import java.sql.*;
public class registerModel {
	public int registerUser(registerBean rg) throws ClassNotFoundException {
        String query = "INSERT INTO user" +
            "  (fn, ln, email, pass, dob, fpd, pp, fb, fln, mn) VALUES " +
            " (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
	    int result = 0;
	    dbConnection dc = new dbConnection();
	    Connection con=dc.getConnection();
	     try{
			PreparedStatement ps=con.prepareStatement(query,Statement.RETURN_GENERATED_KEYS);
			ps.setString(1,rg.getFn());
			ps.setString(2,rg.getLn());
			ps.setString(3,rg.getE());
	        ps.setString(4,rg.getPass());
	        ps.setString(5,rg.getDob());
	        ps.setString(6,rg.getFpd());
	        ps.setString(7,rg.getPp());
	        ps.setString(8,rg.getFb());
	        ps.setString(9,rg.getFln());
	        ps.setString(10,rg.getMn());
	        result = ps.executeUpdate();
	     	}catch (SQLException e) {
	            System.out.println(e);
	        }
	        return result;
	
		}
}
