package Controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Bean.vehicleBean;
import Model.vehicleModel;

@WebServlet("/update")
public class vehicleUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final vehicleModel rm = new vehicleModel();
    public vehicleUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
            int id = Integer.parseInt(request.getParameter("id"));
            String type = request.getParameter("tv");
	        String photo = request.getParameter("txt_img");
	        String color = request.getParameter("color");
	        String reg_num = request.getParameter("reg");
	        vehicleBean vb = new vehicleBean(id, type, reg_num, color, photo);
            rm.update(vb);
            response.sendRedirect("list");
        } catch (SQLException ex) {
        	ex.printStackTrace();
        }
	}

}
