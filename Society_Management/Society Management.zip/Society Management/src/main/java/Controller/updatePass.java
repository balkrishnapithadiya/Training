package Controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Model.dbConnection;
import Bean.loginBean;
@WebServlet("/updatePass")
public class updatePass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public updatePass() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String p = request.getParameter("passwrd");
		String e = request.getParameter("mail");
		dbConnection dc = new dbConnection();
        Connection con=dc.getConnection();
		try{
	        PreparedStatement ps = con.prepareStatement("update user set pass=? where email=?");
	        ps.setString(1, p);
	        ps.setString(2, e);
	        int r = ps.executeUpdate();
	        if(r>0)
	        {
	        	response.sendRedirect("login.jsp");
	        }
	        } catch (SQLException se) {
            System.out.println(se);
        }
	}

}
