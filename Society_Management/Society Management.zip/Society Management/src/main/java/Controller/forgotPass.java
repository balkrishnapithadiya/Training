package Controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Model.forgetPassModel;
import Bean.loginBean;

@WebServlet("/passforgot")
public class forgotPass extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private final forgetPassModel lm = new forgetPassModel();
    public forgotPass() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String e = request.getParameter("txt_email");
		loginBean loginBean = new loginBean();
        loginBean.setEmail(e);
        try {
            if (lm.forget(e)) {
                HttpSession session = request.getSession();
                session.setAttribute("u",e);
                response.sendRedirect("forgotPass.jsp");
            } else {
                response.sendRedirect("login.jsp");
            }
        } catch (SQLException ce) {
            ce.printStackTrace();
        }
		
	}

}
