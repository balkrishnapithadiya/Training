package Controller;
import Bean.vehicleBean;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Model.vehicleModel;
@WebServlet("/insert")
public class vehicleInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final vehicleModel rm = new vehicleModel();
    public vehicleInsert() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String type = request.getParameter("tv");
	        String photo = request.getParameter("txt_img");
	        String color = request.getParameter("color");
	        String reg_num = request.getParameter("reg");
	        int uid = Integer.parseInt(request.getParameter("uid"));
	        vehicleBean vb = new vehicleBean(type, reg_num, photo, color, uid);
	        rm.insert(vb);
	        response.sendRedirect("list");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
