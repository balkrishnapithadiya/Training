package Controller;
import Bean.vehicleBean;
import Model.vehicleModel;
import java.util.*;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/list")
public class listVehicle extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final vehicleModel vm = new vehicleModel();
    public listVehicle() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try 
		{
			List < vehicleBean > listVehicle = vm.selectAll();
	        request.setAttribute("listVehicle", listVehicle);
	        RequestDispatcher dispatcher = request.getRequestDispatcher("listVehicle.jsp");
	        dispatcher.forward(request, response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
