package Controller;
import Bean.loginBean;
import Model.loginModel;
import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/login")
public class loginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private final loginModel lm = new loginModel();
    
    public loginController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String e = request.getParameter("txt_email");
        String p = request.getParameter("txt_password");
        loginBean loginBean = new loginBean();
        loginBean.setEmail(e);
        loginBean.setPassword(p);
        try {
            if (lm.validate(loginBean)) {
                HttpSession session = request.getSession();
                session.setAttribute("un",e);
                response.sendRedirect("index.jsp");
            } else {
                response.sendRedirect("login.jsp");
            }
        } catch (ClassNotFoundException | SQLException ce) {
            ce.printStackTrace();
        }
	}

}
