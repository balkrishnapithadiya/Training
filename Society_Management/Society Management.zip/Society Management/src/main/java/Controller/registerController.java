package Controller;
import Bean.registerBean;
import Model.registerModel;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/register")
public class registerController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private final registerBean rb = new registerBean();
    private final registerModel rm = new registerModel();
   
    public registerController() {
        super();

    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String n=request.getParameter("txt_firstname");
        String p=request.getParameter("txt_password");
        String e=request.getParameter("txt_email");
        String l=request.getParameter("txt_lastname");
        String m=request.getParameter("txt_mn");
        String dob=request.getParameter("txt_dob");
        String fpd=request.getParameter("txt_fpd");
        String pp=request.getParameter("txt_img");
        String fb=request.getParameter("txt_fb");
        String fn=request.getParameter("txt_fn");
        rb.setFn(n);
        rb.setLn(l);
        rb.setE(e);
        rb.setPass(p);
        rb.setMn(m);
        rb.setDob(dob);
        rb.setFpd(fpd);
        rb.setPp(pp);
        rb.setFb(fb);
        rb.setFln(fn);
        
        try {
            if(rm.registerUser(rb)>0)
            {
                response.sendRedirect("login.jsp");
                HttpSession session = request.getSession();
                session.setAttribute("msg","Registered Succesfully!");
            }
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);

        }
		
	}

}
