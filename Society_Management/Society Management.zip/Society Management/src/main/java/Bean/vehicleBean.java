package Bean;

public class vehicleBean {
	private int id;
	private String type;
	private String reg_num;
	private String photo;
	private String color;
	private String reg;
	private int uid;
	
	public vehicleBean(String type, String reg_num, String photo, String color, int uid) {
		super();
		this.type = type;
		this.reg_num = reg_num;
		this.photo = photo;
		this.color = color;
		this.uid = uid;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public vehicleBean(String type, String reg_num, String photo, String color, String reg) {
		super();
		this.type = type;
		this.reg_num = reg_num;
		this.photo = photo;
		this.color = color;
		this.setReg(reg);
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getReg_num() {
		return reg_num;
	}
	public void setReg_num(String reg_num) {
		this.reg_num = reg_num;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public vehicleBean() {
		super();
	}
	public vehicleBean(int id, String type, String reg_num, String color, String photo) {
		super();
		this.id = id;
		this.type = type;
		this.reg_num = reg_num;
		this.color = color;
		this.photo = photo;
	}
	public vehicleBean(String type, String color, String photo) {
		super();
		this.type = type;
		this.color = color;
		this.photo = photo;
	}
	public vehicleBean(String type, String reg_num, String photo, String color) {
		super();
		this.type = type;
		this.reg_num = reg_num;
		this.photo = photo;
		this.color = color;
	}
	
	public String getReg() {
		return reg;
	}
	public void setReg(String reg) {
		this.reg = reg;
	}
	
}
