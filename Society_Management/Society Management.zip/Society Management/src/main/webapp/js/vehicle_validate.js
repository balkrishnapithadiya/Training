function validate()
	{
		var vcolor_v= /^[a-z A-Z]{1,51}$/;
		var vcolor = document.getElementById("vcolor");
		if(!vcolor_v.test(vcolor.value) || vcolor.value=='') 
        {
			alert("Enter Vehicle Color Alphabet Only....!");
            vcolor.focus();
            vcolor.style.background = '#f08080';
            return false;                    
        }
	}