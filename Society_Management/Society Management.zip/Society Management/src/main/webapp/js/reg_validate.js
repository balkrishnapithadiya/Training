function validate()
	{
		var first_name= /^[a-z A-Z]{1,51}$/; 
		var last_name= /^[a-z A-Z]{1,51}$/; 
		var email_valid= /^[\w\d\.]+\@[a-zA-Z\.]+\.[A-Za-z]{1,4}$/; 
		var password_valid=/^(?=.*\d)(?=.*[A-Z])(?=.*[a-z])(?=.*[a-zA-Z!#$@^%&? "])[a-zA-Z0-9!#$@^%&?]{8,20}$/; 
        var mobile_v = /^\d{10}$/;
        var fb_v = /^[A-F]+$/;
        var fn_v = /^[1-21]$/;
        var date_v =/^(0?[1-9]|1[012])[\/\-](0?[1-9]|[12][0-9]|3[01])[\/\-]\d{4}$/;
		
		var fname = document.getElementById("fname"); 
        var lname = document.getElementById("lname"); 
        var email = document.getElementById("email"); 
        var password = document.getElementById("password");
        var mobile = document.getElementById("mn");
        var cp = document.getElementById("cp");
        var fb = document.getElementById("fb");
        var flatn = document.getElementById("flatn");
        var dob = document.getElementById("dob");
        var fpd = document.getElementById("fpd");  
                        
		if(!first_name.test(fname.value) || fname.value=='') 
        {
			alert("Enter Firstname Alphabet Only....!");
            fname.focus();
            fname.style.background = '#f08080';
            return false;                    
        }
		if(!last_name.test(lname.value) || lname.value=='') 
        {
			alert("Enter Lastname Alphabet Only....!");
            lname.focus();
            lname.style.background = '#f08080';
            return false;                    
        }
		if(!email_valid.test(email.value) || email.value=='') 
        {
			alert("Enter Valid Email....!");
            email.focus();
            email.style.background = '#f08080';
            return false;                    
        }
		if(!password_valid.test(password.value) || password.value=='') 
        {
			alert("Password Must Be 6 to 12 and allowed !@#$%&*()<> character");
            password.focus();
            password.style.background = '#f08080';
            return false;                    
        }
        if(password.value != cp.value)  
		{   
		    alert("Passwords did not match");
		    cp.focus();
		    cp.style.background = '#f08080';
            return false;  
		}
		if(!date_v.test(dob.value) || dob.value=='') 
        {
			alert("Please Enter Date of Birth In Specified Format");
            dob.focus();
            dob.style.background = '#f08080';
            return false;                    
        }
        if(!date_v.test(fpd.value) || fpd.value=='') 
        {
			alert("Please Enter Flat Purchase Date In Specified Format");
            fpd.focus();
            fpd.style.background = '#f08080';
            return false;                    
        }
		if(!fb_v.test(fb.value) || fb.value=='') 
        {
			alert("Please Enter Flat Block Number Between A to F");
            fb.focus();
            fb.style.background = '#f08080';
            return false;                    
        }
        if(!fn_v.test(flatn.value) || flatn.value=='') 
        {
			alert("Please Enter Flat Number Between 1 to 20");
            flatn.focus();
            flatn.style.background = '#f08080';
            return false;                    
        }    
        if(!mobile_v.test(mobile.value) || mobile.value=='') 
        {
			alert("Please Enter Mobile Number And It Must Be in Digits");
            mobile.focus();
            mobile.style.background = '#f08080';
            return false;                    
        }   
    }