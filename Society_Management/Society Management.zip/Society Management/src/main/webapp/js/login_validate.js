function validate()
	{
		var email = document.myform.txt_email;
		var password = document.myform.txt_password;
			
		if (email.value == null || email.value == "") 
		{
			window.alert("please enter email ?"); 
			email.style.background = '#f08080';
			email.focus();
			return false;
		}
		if (password.value == null || password.value == "") 
		{
			window.alert("please enter password ?"); 
			password.style.background = '#f08080'; 
			password.focus();
			return false;
		}
	}